package com.project.account.exception;

public class AccountException extends Exception {

	String message;
	
	public AccountException(String s) {
		super(s);
	}
	
	public String getMessage()
	{
		return message;
	}
	
	
}
